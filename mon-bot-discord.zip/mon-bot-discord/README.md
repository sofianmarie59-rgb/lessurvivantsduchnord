# Mon Bot Discord Points

## Installation locale
1. npm install
2. node index.js

## Déploiement Render
- Build command: npm install
- Start command: npm start
- Ajoutez la variable TOKEN dans Render.
